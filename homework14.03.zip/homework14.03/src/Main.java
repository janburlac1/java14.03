import java.util.Random;
import java.util.Scanner;

public class Main {
    //1 Пользователь вводит трёхзначное число.
    //2 Программа должна вывести на экран все
    // цифры этого числа. Какждая цифра
    // должна быть выведена в отдельной строчке.
    //

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("trehznacinoie cislo : ");
        int a = scanner.nextInt();
        System.out.println(a%3);
        System.out.println(a%100/10);
        System.out.println(a%10);

        //Проект 2
        //Компьютер генерирует три произвольных
        // числа из диапазона от 0 до 999.
        //Найдите сумму чисел, выведите на экран.
        //Найдите произведение чисел, выведите на экран.
        System.out.println("proiect 2 : ");
        Random random = new Random();
        int b = random.nextInt(999);
        int c = random.nextInt(999);
        int d = random.nextInt(999);
        System.out.println("cislo = " + b);
        System.out.println("cislo = " + c);
        System.out.println("cislo = " + d);
        System.out.println(" сумму чисел = " + (b + c + d));
        System.out.println(" произведение чисел = " + (b * c * d));




    }
}